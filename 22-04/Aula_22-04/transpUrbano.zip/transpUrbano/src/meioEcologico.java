public interface meioEcologico {
    public void ehEcologico();
}
